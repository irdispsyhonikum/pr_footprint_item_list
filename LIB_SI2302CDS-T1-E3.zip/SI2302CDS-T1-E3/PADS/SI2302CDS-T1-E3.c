*PADS-LIBRARY-SCH-DECALS-V9*

SI2302CDS-T1-E3      32000 32000 100 10 100 10 4 11 0 3 8
TIMESTAMP 2018.09.21.13.51.17
"Default Font"
"Default Font"
450   150   0 8 100 10 "Default Font"
REF-DES
450   50    0 8 100 10 "Default Font"
PART-TYPE
450   -50   0 8 100 10 "Default Font"
*
450   -150  0 8 100 10 "Default Font"
*
CIRCLE 2 10 0 -1
400   100  
100   100  
OPEN   2 10 0 -1
300   100  
300   -100 
OPEN   2 10 0 -1
300   200  
300   300  
OPEN   3 10 0 -1
100   0    
200   0    
200   200  
OPEN   2 10 0 -1
300   100  
230   100  
OPEN   2 10 0 -1
300   200  
230   200  
OPEN   2 10 0 -1
230   0    
300   0    
OPEN   2 10 0 -1
230   220  
230   180  
OPEN   2 10 0 -1
230   -20  
230   20   
OPEN   2 10 0 -1
230   80   
230   120  
COPCLS 4 10 0 -1
230   100  
270   120  
270   80   
230   100  
T0     0     0 0 80    10    0 2 0     -20   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T300   400   90 4 0     20    90 32 0     -20   90 34 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T300   -200  90 0 0     20    90 32 0     -20   90 34 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*
